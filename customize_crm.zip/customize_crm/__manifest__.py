# -*- coding: utf-8 -*-
{
    'name': 'Customize CRM',
    'summary': 'Customizations for CRM pipeline fields and tasks.',
    'version': '13.0.1.0.0',
    'author': 'Naufal Ihsan',
    'website': 'https://example.com',
    'category': 'Sales/CRM',
    'license': 'LGPL-3',
    'depends': ['crm'],
    'data': [
        'security/ir.model.access.csv',
        'views/crm_segment_product_views.xml',
        'views/crm_lead_views.xml',
        'views/crm_menu.xml',
    ],
    'installable': True,
    'application': False,
}
