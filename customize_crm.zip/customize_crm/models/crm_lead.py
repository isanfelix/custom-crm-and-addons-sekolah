# -*- coding: utf-8 -*-
from odoo import api, fields, models


class CrmSegmentProduct(models.Model):
    _name = 'crm.segment.product'
    _description = 'CRM Segment Product'
    _order = 'name'

    name = fields.Char(string='Name', required=True)
    active = fields.Boolean(default=True)


class CrmLeadTask(models.Model):
    _name = 'crm.lead.task'
    _description = 'CRM Lead Task'
    _order = 'deadline asc, id asc'

    lead_id = fields.Many2one(
        'crm.lead',
        string='Lead',
        required=True,
        ondelete='cascade',
        index=True,
    )
    task_name = fields.Char(string='Task', required=True)
    deadline = fields.Datetime(string='Deadline')
    status = fields.Selection(
        [
            ('todo', 'To Do'),
            ('inprogress', 'In Progress'),
            ('done', 'Done'),
        ],
        string='Status',
        default='todo',
        required=True,
    )

    company_id = fields.Many2one(
        'res.company',
        string='Company',
        related='lead_id.company_id',
        store=True,
        readonly=True,
    )


class CrmLead(models.Model):
    _inherit = 'crm.lead'

    is_new_customer = fields.Boolean(string='Is New Customer')
    segment_customer = fields.Selection(
        [
            ('construction', 'Construction'),
            ('bank', 'Bank'),
            ('goverment', 'Government'),
            ('bumd_bumn', 'BUMD/BUMN'),
            ('ministry', 'Ministry'),
            ('swasta', 'Swasta'),
            ('others', 'Others'),
        ],
        string='Customer Segment',
    )
    segment_product_id = fields.Many2one(
        'crm.segment.product',
        string='Product Segment',
    )
    crm_task_ids = fields.One2many(
        'crm.lead.task',
        'lead_id',
        string='Tasks',
    )
    crm_task_count = fields.Integer(
        string='Task Count',
        compute='_compute_crm_task_count',
    )

    @api.depends('crm_task_ids')
    def _compute_crm_task_count(self):
        for lead in self:
            lead.crm_task_count = len(lead.crm_task_ids)

    def action_open_crm_tasks(self):
        self.ensure_one()
        action = self.env.ref('customize_crm.action_crm_lead_task').read()[0]
        action['domain'] = [('lead_id', '=', self.id)]
        action['context'] = {
            'default_lead_id': self.id,
        }
        return action
