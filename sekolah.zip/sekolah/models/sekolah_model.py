from odoo import api, fields, models
from odoo.exceptions import ValidationError

class SekolahKelas(models.Model):
    _name = "sekolah.kelas"
    _description = "Data Kelas"
    _rec_name = "nm_kelas"

    nm_kelas = fields.Char(string="Nama Kelas", required=True)
    wali_kelas_id = fields.Many2one(
        "sekolah.guru",
        string="Wali Kelas",
        required=True,
        domain="[('kelas_id', '=', False)]",
    )
    siswa_ids = fields.One2many("sekolah.siswa", "kelas_id", string="Daftar Siswa")
    jadwal_ids = fields.One2many("sekolah.jadwal", "kelas_id", string="Jadwal Pelajaran")

    _sql_constraints = [
        ("nm_kelas_unique", "unique(nm_kelas)", "Nama kelas harus unik."),
        ("wali_unique", "unique(wali_kelas_id)", "Setiap guru hanya boleh menjadi wali satu kelas."),
    ]

    @api.model
    def action_open_create_form(self):
        action = self.env.ref("sekolah.action_sekolah_kelas").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_kelas_form").id, "form")],
            "res_id": False,
            "target": "current",
        })
        return action

    def action_open_form_view(self):
        self.ensure_one()
        action = self.env.ref("sekolah.action_sekolah_kelas").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_kelas_form").id, "form")],
            "res_id": self.id,
            "target": "current",
        })
        return action

    def action_delete_record(self):
        self.unlink()
        return True

class SekolahSiswa(models.Model):
    _name = "sekolah.siswa"
    _description = "Data Siswa"
    _rec_name = "nm_siswa"

    nis = fields.Char(string="Nomor Induk Siswa", required=True)
    nm_siswa = fields.Char(string="Nama Siswa", required=True)
    jns_kelamin = fields.Selection(
        [("laki", "Laki-laki"), ("perempuan", "Perempuan")],
        string="Jenis Kelamin",
        required=True,
    )
    tgl_lahir = fields.Date(string="Tanggal Lahir")
    agama = fields.Char(string="Agama")
    nm_ayah = fields.Char(string="Nama Ayah")
    nm_ibu = fields.Char(string="Nama Ibu")
    usia = fields.Integer(string="Umur", compute="_compute_usia", store=True)
    alamat = fields.Text(string="Alamat")
    kelas_id = fields.Many2one("sekolah.kelas", string="Kelas")

    _sql_constraints = [
        ("nis_unique", "unique(nis)", "Nomor Induk Siswa harus unik."),
    ]

    @api.depends("tgl_lahir")
    def _compute_usia(self):
        for rec in self:
            if rec.tgl_lahir:
                today = fields.Date.context_today(rec)
                rec.usia = today.year - rec.tgl_lahir.year - (
                    (today.month, today.day) < (rec.tgl_lahir.month, rec.tgl_lahir.day)
                )
            else:
                rec.usia = 0

    @api.model
    def create(self, vals):
        if not vals.get("nis"):
            seq = self.env["ir.sequence"].next_by_code("sekolah.siswa.nis")
            if not seq:
                raise ValidationError("Sequence NIS siswa belum dikonfigurasi.")
            vals["nis"] = seq
        return super().create(vals)

    @api.model
    def action_open_create_form(self):
        action = self.env.ref("sekolah.action_sekolah_siswa").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_siswa_form").id, "form")],
            "res_id": False,
            "target": "current",
        })
        return action

    def action_open_form_view(self):
        self.ensure_one()
        action = self.env.ref("sekolah.action_sekolah_siswa").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_siswa_form").id, "form")],
            "res_id": self.id,
            "target": "current",
        })
        return action

    def action_delete_record(self):
        self.unlink()
        return True

class SekolahMataPelajaran(models.Model):
    _name = "sekolah.mapel"
    _description = "Data Mata Pelajaran"
    _rec_name = "nm_matapelajaran"

    nm_matapelajaran = fields.Char(string="Nama Mata Pelajaran", required=True)
    jurusan = fields.Char(string="Jurusan")
    guru_ids = fields.One2many("sekolah.guru", "mapel_id", string="Guru Pengampu")
    jadwal_ids = fields.One2many("sekolah.jadwal", "mapel_id", string="Jadwal Mapel")

    _sql_constraints = [
        ("mapel_unique", "unique(nm_matapelajaran)", "Nama mata pelajaran harus unik."),
    ]

    @api.model
    def action_open_create_form(self):
        action = self.env.ref("sekolah.action_sekolah_mapel").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_mapel_form").id, "form")],
            "res_id": False,
            "target": "current",
        })
        return action

    def action_open_form_view(self):
        self.ensure_one()
        action = self.env.ref("sekolah.action_sekolah_mapel").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_mapel_form").id, "form")],
            "res_id": self.id,
            "target": "current",
        })
        return action

    def action_delete_record(self):
        self.unlink()
        return True

class SekolahGuru(models.Model):
    _name = "sekolah.guru"
    _description = "Data Guru"
    _rec_name = "nm_guru"

    nip = fields.Char(string="Nomor Induk Pegawai", required=True)
    nm_guru = fields.Char(string="Nama Guru", required=True)
    jns_kelamin = fields.Selection(
        [("laki", "Laki-laki"), ("perempuan", "Perempuan")],
        string="Jenis Kelamin",
        required=True,
    )
    mapel_id = fields.Many2one("sekolah.mapel", string="Mata Pelajaran", required=True)
    usia = fields.Integer(string="Umur")
    no_telp = fields.Char(string="Nomor Telepon")
    alamat = fields.Text(string="Alamat")
    kelas_id = fields.One2many("sekolah.kelas", "wali_kelas_id", string="Kelas Diasuh")
    jadwal_ids = fields.One2many("sekolah.jadwal", "guru_id", string="Jadwal Mengajar")

    _sql_constraints = [
        ("nip_unique", "unique(nip)", "NIP harus unik."),
    ]

    @api.constrains("mapel_id")
    def _constrain_unique_mapel(self):
        for guru in self:
            if guru.mapel_id and self.search_count([("mapel_id", "=", guru.mapel_id.id)]) > 1:
                raise ValidationError("Satu mata pelajaran hanya boleh memiliki satu guru pengampu.")

    @api.model
    def create(self, vals):
        if not vals.get("nip"):
            seq = self.env["ir.sequence"].next_by_code("sekolah.guru.nip")
            if not seq:
                raise ValidationError("Sequence NIP guru belum dikonfigurasi.")
            vals["nip"] = seq
        return super().create(vals)

    @api.model
    def action_open_create_form(self):
        action = self.env.ref("sekolah.action_sekolah_guru").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_guru_form").id, "form")],
            "res_id": False,
            "target": "current",
        })
        return action

    def action_open_form_view(self):
        self.ensure_one()
        action = self.env.ref("sekolah.action_sekolah_guru").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_guru_form").id, "form")],
            "res_id": self.id,
            "target": "current",
        })
        return action

    def action_delete_record(self):
        self.unlink()
        return True

class SekolahJadwal(models.Model):
    _name = "sekolah.jadwal"
    _description = "Jadwal Pelajaran"
    _rec_name = "name"

    name = fields.Char(compute="_compute_name", store=True)
    kelas_id = fields.Many2one("sekolah.kelas", string="Kelas", required=True)
    mapel_id = fields.Many2one("sekolah.mapel", string="Mata Pelajaran", required=True)
    guru_id = fields.Many2one("sekolah.guru", string="Guru Pengajar", required=True)
    hari = fields.Selection(
        [
            ("senin", "Senin"),
            ("selasa", "Selasa"),
            ("rabu", "Rabu"),
            ("kamis", "Kamis"),
            ("jumat", "Jumat"),
        ],
        string="Hari",
        required=True,
    )
    jam = fields.Float(
        string="Jam Mulai",
        help="Gunakan format jam desimal (misal 8.5 = 08:30).",
    )

    _sql_constraints = [
        ("unique_slot", "unique(kelas_id, hari, jam)", "Sudah ada jadwal di kelas dan waktu tersebut."),
    ]

    @api.depends("kelas_id", "mapel_id", "hari", "jam")
    def _compute_name(self):
        for rec in self:
            if rec.kelas_id and rec.mapel_id:
                rec.name = f"{rec.kelas_id.nm_kelas} - {rec.mapel_id.nm_matapelajaran}"
            else:
                rec.name = False

    @api.model
    def action_open_create_form(self):
        action = self.env.ref("sekolah.action_sekolah_jadwal").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_jadwal_form").id, "form")],
            "res_id": False,
            "target": "current",
        })
        return action

    def action_open_form_view(self):
        self.ensure_one()
        action = self.env.ref("sekolah.action_sekolah_jadwal").read()[0]
        action.update({
            "view_mode": "form",
            "views": [(self.env.ref("sekolah.view_sekolah_jadwal_form").id, "form")],
            "res_id": self.id,
            "target": "current",
        })
        return action

    def action_delete_record(self):
        self.unlink()
        return True